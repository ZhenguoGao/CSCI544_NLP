from hw3_corpus_tool import *

import sys
import pycrfsuite

global X_train
global Y_train
global X_test
X_test = []
X_train = []
Y_train = []



def get_feature(dialogUtterance):
    global X_train
    global Y_train


    speakerChangedFeature = '0'
    firstUtteranceFeature = '0'
    # tokenFeature = "TOKEN_"
    # posFeature = "POS_"

    lastSpeaker = None
    firstUtterance = True
    onefile = []
    tag_list = []

    for i in range(0, len(dialogUtterance)):

            tokenList = []
            posList = []

            oneline=[]



            oneUtterance = dialogUtterance[i]
            Y_train.append(oneUtterance[0])
            speaker = oneUtterance[1]
            pos = oneUtterance[2]

            if pos is not None:
                for posTag in pos:
                    tokenList.append(posTag[0])
                    posList.append(posTag[1])

            if lastSpeaker is None:
                lastSpeaker = speaker


            elif lastSpeaker != speaker:
                speakerChangedFeature = '1'
                lastSpeaker = speaker

            else:
                speakerChangedFeature = '0'


            if firstUtterance:
                firstUtteranceFeature = '2'
                firstUtterance = False
            else:
                firstUtteranceFeature = '0'


            oneline=[speakerChangedFeature,firstUtteranceFeature]
            oneline.extend(tokenList)
            oneline.extend(posList)
            X_train.append(oneline)

def get_feature1(dialogUtterance):

                global X_test

                speakerChangedFeature = '0'
                firstUtteranceFeature = '0'
                # tokenFeature = "TOKEN_"
                # posFeature = "POS_"

                lastSpeaker = None
                firstUtterance = True
                onefile = []


                for i in range(0, len(dialogUtterance)):

                    tokenList = []
                    posList = []

                    oneline = []

                    oneUtterance = dialogUtterance[i]
                    Y_train.append(oneUtterance[0])
                    speaker = oneUtterance[1]
                    pos = oneUtterance[2]

                    if pos is not None:
                        for posTag in pos:
                            tokenList.append(posTag[0])
                            posList.append(posTag[1])

                    if lastSpeaker is None:
                        lastSpeaker = speaker


                    elif lastSpeaker != speaker:
                        speakerChangedFeature = '1'
                        lastSpeaker = speaker

                    else:
                        speakerChangedFeature = '0'

                    if firstUtterance:
                        firstUtteranceFeature = '2'
                        firstUtterance = False
                    else:
                        firstUtteranceFeature = '0'

                    oneline = [speakerChangedFeature, firstUtteranceFeature]
                    oneline.extend(tokenList)
                    oneline.extend(posList)
                    X_test.append(oneline)

    # Y_train.append(tag_list)


# def fun(path):
#
#     global X_test
#
#
#
#     outfile = open('result2.txt', 'w', encoding='latin1')
#     tagger = pycrfsuite.Tagger()
#     tagger.open('conll2002-esp.crfsuite')
#     for root, dirs, files in os.walk(path):
#
#         for fn in files:
#
#             # print root, fn
#             k = os.path.join(root, fn)
#             outfile.write(str(k))
#             outfile.write('\n')
#             dictDialogUtterance = get_utterances_from_filename(k)
#             print(dictDialogUtterance)
#
#             for k in dictDialogUtterance:
#                 get_feature1(k)
#                 print(X_test)
#                 outfile.write(str('\n'.join(tagger.tag(X_test))))
#                 outfile.write('\n')
#                 # X_test = []









def main():

    global X_test
    # dir_path1 = '/Users/Zhenguo/PycharmProjects/Python-study/labeled_data'
    dir_path1 = sys.argv[1]

    dictDialogUtterance=get_data(dir_path1)

    for k in dictDialogUtterance:
        get_feature(k)

    print(len(X_train))
    print(len(Y_train))

    trainer = pycrfsuite.Trainer(verbose=False)


    trainer.append(X_train, Y_train)


    trainer.set_params({
            'c1': 1.0,  # coefficient for L1 penalty
            'c2': 1e-3,  # coefficient for L2 penalty
            'max_iterations': 50,  # stop earlier

            # include transitions that are possible, but not observed
            'feature.possible_transitions': True
    })
    # model_filename=str(tmpdir.join('model.crfsuite'))

    trainer.train('conll2002-esp.crfsuite')

    # dir_path2 = '/Users/Zhenguo/PycharmProjects/Python-study/aaaa/'
    dir_path2 = sys.argv[2]
    # fun(dir_path2)
    tagger = pycrfsuite.Tagger()
    tagger.open('conll2002-esp.crfsuite')

    dir_path3 = sys.argv[3]
    outfile = open(dir_path3, 'w', encoding='latin1')

    dictDialogUtterance = get_data2(dir_path2)
    print(h)

    i = 0
    for k in dictDialogUtterance:
                    get_feature1(k)
                    print(X_test)
                    outfile.write(h[i])
                    outfile.write('\n')
                    outfile.write(str('\n'.join(tagger.tag(X_test))))
                    outfile.write('\n')
                    outfile.write('\n')
                    X_test=[]
                    i += 1






    # print('\n'.join(tagger.tag(X_test)))
















    # for element in dictDialogUtterance:
    #
    #
    #         act_tag = element[0][0]
    #         speaker = element[1]
    #         pos = element[2]
    #         text = element[3]
    #         print(act_tag)
    #         print(speaker)
    #         print(pos)
    #         print(text)



if __name__ == '__main__':main()