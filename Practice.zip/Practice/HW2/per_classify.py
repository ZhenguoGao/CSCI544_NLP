import sys
import os
import glob
import random
from collections import defaultdict
import sys
import os
import glob
from collections import defaultdict
import ast
import math


global precision_number_ham
global precision_actually_ham
global precision_number_spam
global precision_actually_spam
global recall_number_ham
global recall_actually_ham
global recall_number_spam
global recall_actually_spam

global dict_for_spam_ham
global bias
dict_for_spam_ham = {}
bias=0


def classify_file(f):
    global dict_for_spam_ham
    global bias
    total=0
    file = open(f, 'r', encoding='latin1')
    for line in file:
        words = line.split(" ")
        for word in words:

            if (dict_for_spam_ham.get(word)):
                total += float(dict_for_spam_ham[word])

            else:
                pass

    if(total+bias>0):
        return ("ham")

    else:
        return ("spam")
    file.close()

def fun(path):

    outfile = open("nboutput.txt", 'w',encoding='latin1')

    for root, dirs, files in os.walk(path):

            for fn in files:

                k=os.path.join(root,fn)
                outfile.write(str(classify_file(k) + " " + k))
                outfile.write("\n")
    outfile.close()

def precision():
    global precision_number_ham
    global precision_actually_ham
    global precision_number_spam
    global precision_actually_spam
    precision_number_ham=0
    precision_actually_ham=0
    precision_number_spam=0
    precision_actually_spam=0
    file= open('nboutput.txt','r',encoding='latin1')
    for line in file:
            words = line.split(" ")
            if "ham" in words[0]:
                precision_number_ham +=1
                if words[0] in words[1]:
                    precision_actually_ham+=1
            if "spam" in words[0]:
                precision_number_spam += 1
                if words[0] in words[1]:
                    precision_actually_spam += 1
    print(str((precision_actually_ham/precision_number_ham)*100))
    print(str((precision_actually_spam / precision_number_spam) * 100))


def recall():
    global recall_number_ham
    global recall_actually_ham
    global recall_number_spam
    global recall_actually_spam
    recall_number_ham=0
    recall_actually_ham=0
    recall_number_spam=0
    recall_actually_spam=0
    file = open('nboutput.txt', 'r',encoding='latin1')
    for line in file:
        words = line.split(" ")
        if "ham" in words[1]:
            recall_actually_ham += 1
            if words[0] in words[1]:
                recall_number_ham += 1
        if "spam" in words[1]:
            recall_actually_spam += 1
            if words[0] in words[1]:
                recall_number_spam += 1
    print(str((recall_number_ham / recall_actually_ham) * 100))
    print(str((recall_number_spam / recall_actually_spam) * 100))

def score():
    global recall_number_ham
    global recall_actually_ham
    global recall_number_spam
    global recall_actually_spam

    global precision_number_ham
    global precision_actually_ham
    global precision_number_spam
    global precision_actually_spam

    print(str((2*(precision_actually_ham/precision_number_ham)*(recall_number_ham / recall_actually_ham))/((precision_actually_ham/precision_number_ham)+(recall_number_ham / recall_actually_ham))))
    print(str((2*(precision_actually_spam/precision_number_spam)*(recall_number_spam / recall_actually_spam))/((precision_actually_spam/precision_number_spam)+(recall_number_spam / recall_actually_spam))))






def main():

        global dict_for_spam_ham
        global bias

        file = open("per_model.txt", 'r',encoding='latin1')
        k = file.read()
        element=k.split("*************")

        dict_for_spam_ham=ast.literal_eval(element[0])
        bias =float(element[1])
        file.close()


        # input_file = sys.argv[1]
        # ouput_file = sys.argv[2]
        dir_path = '/Users/Zhenguo/PycharmProjects/Python-study/dev'
        fun(dir_path)
        precision()
        recall()
        score()






if __name__ == '__main__':main()