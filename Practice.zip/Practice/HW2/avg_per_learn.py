import sys
import os
import glob
import random
from collections import defaultdict

global bias
global dict_for_spam_ham_avg
global bias_avg
global dict_for_spam_ham_final
global bias_final
global count
global total_distinct
global total_list
# global total_list1
total_list = []
total_distinct = {}
dict_for_spam_ham_avg = {}
dict_for_spam_ham_final = {}
bias = 0
bias_avg = 0
bias_final = 0
count = 1
# total_list1=[]


def check_file():
    global total_list
    global total_distinct
    global dict_for_spam_ham_avg
    global bias
    global bias_avg
    # global total_list1
    global count
    for element in total_list:  # read dictionary one by one
            if element.get("ham"):  # judge the read dictionary's key equal ham or spam
                calculate = 0
                for word in element["ham"]:  # get token from one ham dictionary
                    calculate += total_distinct[word]  # if inculde add the value to calculate

                if (calculate + bias <= 0):  # judge change weight or not

                    for word in element["ham"]:
                        total_distinct[word] = total_distinct[word] + 1
                        dict_for_spam_ham_avg[word] = dict_for_spam_ham_avg[word] + count
                    bias += 1
                    bias_avg += count

                count += 1

            elif element.get("spam"):
                calculate = 0
                for word in element["spam"]:  # get token from one spam dictionary
                    calculate += total_distinct[word]  # if inculde add the value to calculate

                if (calculate + bias >= 0):

                    for word in element["spam"]:
                        total_distinct[word] = total_distinct[word] - 1
                        dict_for_spam_ham_avg[word] = dict_for_spam_ham_avg[word] - count

                    bias -= 1
                    bias_avg -= count

                count += 1


def main():
    global bias
    global dict_for_spam_ham_avg
    global bias_avg
    global dict_for_spam_ham_final
    global bias_final
    global count
    # global total_list1
    global total_distinct
    global total_list
    b = 30
    # kkk=0
    # input_file = sys.argv[1]
    dir_path = '/Users/Zhenguo/PycharmProjects/Python-study/train/'
    for root, dirs, files in os.walk(dir_path):

        for fn in files:
            k = os.path.join(root, fn)  # one path of txt file
            if "ham" in k:
                file = open(k, 'r', encoding='latin1')
                ham_dict = {"ham": []}
                for line in file:
                    words = line.split(" ")
                    for word in words:
                        if word not in total_distinct:
                            # check each word weather in total_dictinct
                            dict2 = {word: 0}  # if not add it
                            total_distinct.update(dict2)
                        ham_dict["ham"].append(word)
                total_list.append(ham_dict)  # append small dict to big list
            elif "spam" in k:
                file = open(k, 'r', encoding='latin1')
                ham_dict = {"spam": []}
                for line in file:
                    words = line.split(" ")
                    for word in words:
                        if word not in total_distinct:  # check each word weather in total_dictinct
                            dict2 = {word: 0}  # if not add it
                            total_distinct.update(dict2)
                        ham_dict["spam"].append(word)
                total_list.append(ham_dict)
    dict_for_spam_ham_avg=total_distinct.copy()
    random.shuffle(total_list)
    # while kkk < int(len(total_list) / 10):
    #     for kk in total_list:
    #         total_list1.append(kk)
    #         kkk += 1
                # print(str(fn)
    while (b > 0):
        b -= 1
        random.shuffle(total_list)  # shuffle the big list that contain all the small dictionary
        # random.shuffle(total_list1)
        check_file()

    for key in total_distinct:
        total_distinct[key]= str(total_distinct[key] - (1 / count) * dict_for_spam_ham_avg[key])

    bias_final = bias - (1 / count) * bias_avg

    outfile = open('per_model.txt', 'w', encoding="latin1")
    outfile.write(str(total_distinct))
    outfile.write(str("*************"))
    outfile.write(str(bias_final))
    outfile.close()


if __name__ == '__main__': main()
